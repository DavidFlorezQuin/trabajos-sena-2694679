package com.sena.earthcrud.IRepository;

import com.sena.earthcrud.Entity.Pais;

import org.springframework.data.jpa.repository.JpaRepository;


public interface IPaisRepository extends JpaRepository<Pais, Long>{
}
