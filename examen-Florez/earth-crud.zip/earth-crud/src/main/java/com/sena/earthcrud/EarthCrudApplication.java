package com.sena.earthcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EarthCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EarthCrudApplication.class, args);
	}

}
