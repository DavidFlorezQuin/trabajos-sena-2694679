package com.sena.earthcrud.IRepository;

import com.sena.earthcrud.Entity.Continente;

import org.springframework.data.jpa.repository.JpaRepository;


public interface IContinenteRepository extends JpaRepository<Continente, Long>{
}
